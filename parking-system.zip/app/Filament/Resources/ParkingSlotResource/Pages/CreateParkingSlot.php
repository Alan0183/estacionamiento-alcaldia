<?php

namespace App\Filament\Resources\ParkingSlotResource\Pages;

use App\Filament\Resources\ParkingSlotResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateParkingSlot extends CreateRecord
{
    protected static string $resource = ParkingSlotResource::class;
}
